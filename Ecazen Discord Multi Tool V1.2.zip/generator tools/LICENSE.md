## **YAZILIM LİSANS SÖZLEŞMESİ (ECAZEN TOOL)**

Telif Hakkı (c) 2025 **Ecazen** (discord.gg/ecazen). Tüm Hakları Saklıdır.



Bu yazılımın ve ilgili dokümantasyon dosyalarının ("Yazılım") kullanımı, kopyalanması ve dağıtılması aşağıdaki koşullara tabidir:



1\. Mülkiyet Hakları: Yazılımın tüm mülkiyeti, kaynak kodları, banner tasarımları ve algoritma hakları doğrudan **Ecazen**'e aittir. Yazılımın içeriğinde bulunan hiçbir görsel veya teknik öğe, hak sahibinin yazılı izni olmaksızın değiştirilemez veya kaldırılamaz.



2\. Kullanım Kısıtlamaları:



Yeniden Satış: Bu Yazılımın ücretli veya ücretsiz olarak yeniden satılması, kiralanması veya ticari bir amaçla pazarlanması kesinlikle yasaktır.



Tersine Mühendislik: Yazılımın kaynak kodlarının karartılmış kısımlarını açmak, tersine mühendislik (reverse engineering) yapmak veya lisans kontrol mekanizmalarını devre dışı bırakmak yasaktır.



Dağıtım: Yazılım yalnızca orijinal dağıtım kanalları **(discord.gg/ecazen)** üzerinden paylaşılabilir. Yazılımın izinsiz kopyalanması ve başka platformlarda "kendi malıymış gibi" sunulması telif hakkı ihlali sayılır.



3\. Sorumluluk Reddi: Yazılım "OLDUĞU GİBİ" sunulmaktadır. Yazılımın kullanımından doğabilecek her türlü hukuki, teknik veya kişisel sorumluluk kullanıcıya aittir. Geliştirici (Ecazen), yazılımın kötüye kullanımı veya üçüncü şahıslara verilen zararlardan dolayı hiçbir şekilde sorumlu tutulamaz.



4\. Lisans İptali: Yukarıdaki şartlardan herhangi birinin ihlal edilmesi durumunda, kullanıcının yazılımı kullanma hakkı otomatik olarak sona erer ve ilgili platformlar üzerinden (Discord vb.) yaptırım uygulanma hakkı saklı tutulur.

